simple express demo:
- https://medium.com/featurepreneur/develop-a-backend-server-for-your-application-using-express-29deeae40ed1

express with mongo:
- https://www.freecodecamp.org/news/build-a-restful-api-using-node-express-and-mongodb/

creating project having express as backend and react as frontend
- https://www.youtube.com/watch?v=w3vs4a03y3I

react router demo:
- https://blog.logrocket.com/complete-guide-authentication-with-react-router-v6/

mongodb setup:
- sign up at https://account.mongodb.com/account/login 
- create free shared cluster
- authenticate using username and password, create user
- verify it added your ip address
